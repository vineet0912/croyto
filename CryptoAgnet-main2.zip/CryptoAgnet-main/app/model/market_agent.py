from agno.agent import Agent
from agno.models.groq import Groq


market_agent = Agent(
    model= Groq(id="openai/gpt-oss-120b"),

    name="Market Analyst",
    instructions="""
    Analyze crypto market data.
    
    Determine:
    - bullish or bearish trend
    - trading volume strength
    - volatility
    """

)