from agno.agent import Agent
from agno.models.groq import Groq
import os
from dotenv import load_dotenv
load_dotenv()

os.environ["GROQ_API_KEY"] = os.getenv("GROQ_API")


investment_agent = Agent(
    model= Groq(id="openai/gpt-oss-120b"),
    name="Investment Advisor",
    instructions="""
    You are a crypto investment analyst.
    
    Use market data and news sentiment to produce:

    - market outlook
    - risks
    - short investment insight
    """
)