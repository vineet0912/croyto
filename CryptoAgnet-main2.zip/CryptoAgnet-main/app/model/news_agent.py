from agno.agent import Agent
from agno.models.groq import Groq
import os
from dotenv import load_dotenv

load_dotenv()

os.environ["GROQ_API_KEY"] = os.getenv("GROQ_API")


news_agent = Agent(
    model= Groq(id="openai/gpt-oss-120b"),
    name="News Analyst",
    instructions="""
    Analyze crypto news headlines.
    
    Determine:
    - sentiment
    - major market impact
    - positive or negative signals
    """
)