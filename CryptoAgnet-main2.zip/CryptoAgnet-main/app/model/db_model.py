from sqlalchemy import Column, Integer, Float, String, Date
from app.database.database import Base

class CryptoPrice(Base):

    __tablename__ = "crypto_prices"

    id = Column(Integer, primary_key=True, index=True)

    symbol = Column(String, index=True)
    asset_type = Column(String, default="Crypto")
    
    date = Column(Date, index=True)

    open = Column(Float)
    high = Column(Float)
    low = Column(Float)
    close = Column(Float)

    volume = Column(Float)