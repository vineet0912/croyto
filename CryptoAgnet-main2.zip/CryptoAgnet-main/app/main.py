from fastapi import FastAPI
from app.routes.analysis_route import router
from app.routes.history_route import history_router
from app.routes.latest_price_route import price_router
from app.routes.home import home_router
from app.routes.favicon import icon_router

app = FastAPI()
app.include_router(icon_router)
app.include_router(home_router)
app.include_router(router)
app.include_router(history_router)
app.include_router(price_router)