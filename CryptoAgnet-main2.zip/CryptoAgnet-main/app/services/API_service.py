 

from fastapi import HTTPException
from sqlalchemy.orm import Session
from app.model.db_model import CryptoPrice  # adjust path if needed
from sqlalchemy import text
from app.services.currency_converter import convert_to_inr


def get_crypto_data(db: Session, coin="BTC-USD"):

    # Fetch latest record for that coin
    data = (
        db.query(CryptoPrice)
        .filter(CryptoPrice.symbol == coin)
        .order_by(CryptoPrice.date.desc())
        .first()
    )
    
    if not data:
        return {"error": "Coin not found in database"}

    return convert_to_inr({
        "symbol":data.symbol,
        "date":str(data.date),
        "price": data.close,
        "open":data.open,
        "high":data.high,
        "low":data.low,
        "volume": data.volume,    
    })

def get_latest_price(db, symbol: str):
    query =  text("""
        SELECT volume, id, date, open, high, low, close, symbol
        FROM crypto_prices
        WHERE symbol = :symbol
        ORDER BY date DESC
        LIMIT 1
 
""")
    
    result = db.execute(query, {"symbol": symbol}).fetchone()
    if not result:
        raise HTTPException(status_code=404, detail="symbol not found")
    return convert_to_inr({
        "volume":result._mapping["volume"],
        "id":result._mapping["id"],
        "date":str(result._mapping["date"]),
        "open":result._mapping["open"],
        "high":result._mapping["high"],
        "low":result._mapping["low"],
        "close":result._mapping["close"],
        "symbol": result._mapping["symbol"],
 
    })


def get_history(db, symbol, start=None, end=None, limit=100, offset=0):
    query = """
        SELECT volume, id, date, open, high, low, close, symbol
        FROM crypto_prices
        WHERE symbol = :symbol
    """

    params = {"symbol": symbol}

    if start:
        query += " AND date >= :start"
        params["start"] = start

    if end:
        query += " AND date <= :end"
        params["end"] = end

    query += " ORDER BY date DESC LIMIT :limit OFFSET :offset"
    params["limit"] = limit
    params["offset"] = offset

    result = db.execute(text(query), params).fetchall()

    return convert_to_inr([dict(row._mapping) for row in result])