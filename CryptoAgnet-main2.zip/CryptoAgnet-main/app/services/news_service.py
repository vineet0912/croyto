# import requests
# from dotenv import load_dotenv
# import os

# load_dotenv()
# API_KEY = os.getenv("CRYPTOPANIC_API")
# # ticker='BTC'
# # url = f"https://cryptopanic.com/api/v1/posts/?auth_token={API_KEY}&currencies={ticker}"

# # response = requests.get(url)

# # print(response.text)

# # data = response.json()

# def get_crypto_news(ticker="BTC"):

#     url = f"https://cryptopanic.com/api/v1/posts/?auth_token={API_KEY}&currencies={ticker}"

#     response = requests.get(url).json()

#     news_list = []

#     for post in response["results"][:5]:
#         news_list.append({
#             "title": post["title"],
#             "url": post["url"]
#         })

#     return news_list




import requests
from dotenv import load_dotenv
load_dotenv()
import os 


API_KEY = os.getenv("NEWS_API") 


def get_crypto_news(coin):

    url = "https://newsapi.org/v2/everything"

    params = {
        "q": coin,
        "language": "en",
        "sortBy": "publishedAt",
        "apiKey": API_KEY,
        "pageSize": 5
    }

    try:
        response = requests.get(url, params=params)
        data = response.json()
        print(data)
    except Exception as e:
        print(f"Error fetching news: {e}")
        return []

    if data.get("status") != "ok":
        print(f"News API error: {data.get('message', 'Unknown error')}")
        return []

    news_list = []

    for article in data.get("articles", []):
        news_list.append({
            "title": article["title"],
            "url": article["url"],
            "source": article["source"]["name"]
        })

    return news_list

# if __name__ == "__main__":
#     print(get_crypto_news("bitcoin"))