from transformers import pipeline

sentiment_model = pipeline("sentiment-analysis")

def analyze_sentiment(news):

    if not news:
        return {"sentiment_score": 0, "sentiment_label": "neutral"}

    scores = []

    for article in news:

        result = sentiment_model(article["title"])[0]

        label = result["label"]
        score = result["score"]

        if label == "POSITIVE":
            scores.append(score)
        else:
            scores.append(-score)

    sentiment_score = sum(scores) / len(scores)

    if sentiment_score > 0.2:
        sentiment_label = "bullish"
    elif sentiment_score < -0.2:
        sentiment_label = "bearish"
    else:
        sentiment_label = "neutral"

    return {
        "sentiment_score": sentiment_score,
        "sentiment_label": sentiment_label
    }