def calculate_confidence(sentiment_score, rsi):

    sentiment_component = abs(sentiment_score)

    if rsi > 60:
        technical_component = 0.8
    elif rsi < 40:
        technical_component = 0.6
    else:
        technical_component = 0.5

    confidence = (sentiment_component * 0.4) + (technical_component * 0.6)

    return round(confidence * 100, 2)