import pandas as pd
import ta
from sqlalchemy.orm import Session
from app.model.db_model import CryptoPrice
from app.services.currency_converter import convert_to_inr


def get_technical_indicators(db: Session, coin="BTC-USD"):

    # Fetch last 60 days of data from DB to compute indicators
    rows = (
        db.query(CryptoPrice)
        .filter(CryptoPrice.symbol == coin)
        .order_by(CryptoPrice.date.desc())
        .limit(60)
        .all()
    )

    if not rows or len(rows) < 14:
        return {
            "rsi": None,
            "rsi_signal":None,
            "ma50": None,
            "price": None,
            "error": "Not enough historical data for technical indicators"
        }

    # Reverse to chronological order
    rows = rows[::-1]

    df = pd.DataFrame([{
        "date": r.date,
        "price": r.close
    } for r in rows])
    
    df["rsi"] = ta.momentum.RSIIndicator(df["price"]).rsi()

    df["ma50"] = df["price"].rolling(50).mean()

    latest = df.iloc[-1]
    rsi_value = latest["rsi"]

    if pd.isna(rsi_value):
        rsi_signal = None
    elif rsi_value >= 70:
        rsi_signal = "OVERBOUGHT"
    elif rsi_value <= 30:
        rsi_signal = "OVERSOLD"
    else:
        rsi_signal = "NEUTRAL"


    return convert_to_inr({
        "rsi": round(latest["rsi"], 2) if pd.notna(latest["rsi"]) else None,
        "ma50": round(latest["ma50"], 2) if pd.notna(latest["ma50"]) else None,
        "rsi_signal":rsi_signal,
        "price": round(latest["price"], 2)
    })