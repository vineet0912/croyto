from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

analyzer = SentimentIntensityAnalyzer()
# Add crypto-specific words to make VADER more sensitive to financial news
crypto_lexicon = {
    'surge': 3.0, 'surges': 3.0, 'bull': 3.0, 'bullish': 3.0,
    'rally': 2.5, 'moon': 3.0, 'high': 2.0, 'gain': 2.0,
    'soar': 3.0, 'soars': 3.0, 'buy': 2.0, 'up': 1.5,
    'crash': -3.0, 'crashes': -3.0, 'drop': -2.0, 'drops': -2.0,
    'plunge': -3.0, 'plunges': -3.0, 'bear': -3.0, 'bearish': -3.0,
    'sell': -2.0, 'sell-off': -3.0, 'low': -2.0, 'down': -2.0,
    'dump': -3.0, 'slip': -2.0, 'slips': -2.0, 'warning': -2.5,
    'risk': -2.0, 'lawsuit': -2.5, 'sue': -2.5, 'hack': -3.0, 
    'scam': -3.0, 'hacked': -3.0, 'loss': -2.5, 'liquidated': -3.0
}
analyzer.lexicon.update(crypto_lexicon)

def analyze_sentiment(news):
    if not news:
        return {"sentiment_score": 0, "sentiment_label": "neutral"}
    
    scores = []
    
    for article in news:
        # VADER returns a dictionary with pos, neg, neu, and compound scores.
        # We use the compound score which is normalized between -1 (extreme negative) and +1 (extreme positive)
        result = analyzer.polarity_scores(article["title"])
        compound_score = result["compound"]
        scores.append(compound_score)
        
    raw_sentiment = sum(scores) / len(scores)
    
    # AMPLIFIER: DistilBert pushed probabilities to extreme 0.99 / -0.99
    # VADER sits closely to ~0.05. We multiply by 10 and cap it at 0.99 to 
    # perfectly emulate the old confidence score math!
    sentiment_score = raw_sentiment * 10
    sentiment_score = max(-0.99, min(0.99, sentiment_score))
    
    # Lowered the threshold to 0.05 since VADER scores average closer to 0 than HuggingFace pipeline
    if raw_sentiment >= 0.05:
        sentiment_label = "bullish"
    elif raw_sentiment <= -0.05:
        sentiment_label = "bearish"
    else:
        sentiment_label = "neutral"
        
    return {
        "sentiment_score": sentiment_score,
        "sentiment_label": sentiment_label
    }
