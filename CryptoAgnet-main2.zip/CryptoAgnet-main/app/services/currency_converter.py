def convert_to_inr(data, rate=94.85):
    """
    Converts USD values to INR in the given dictionary or list of dictionaries.
    Keys corresponding to monetary values are converted.
    """
    keys_to_convert = ["price", "open", "high", "low", "close", "volume", "ma50"]
    
    if isinstance(data, dict):
        new_data = dict(data)
        for key in keys_to_convert:
            if key in new_data and new_data[key] is not None:
                new_data[key] = round(float(new_data[key]) * rate, 2)
        return new_data
    elif isinstance(data, list):
        return [convert_to_inr(item, rate) for item in data]
    elif isinstance(data, (int, float)):
        return round(data * rate, 2)
        
    return data
