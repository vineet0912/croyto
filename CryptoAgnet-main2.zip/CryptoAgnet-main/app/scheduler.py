import yfinance as yf
from datetime import datetime
from app.database.database import SessionLocal
from app.model.db_model import CryptoPrice

def fetch_daily_data():
    """
    Standalone task to fetch daily financial data for cryptocurrencies using yfinance.
    Intended to be executed by a CRON job (e.g., GitHub Actions).
    """
    db = SessionLocal()
    try:
        # You can add more symbols to this list
        symbols = ["AAVE-USD",
"ADA-USD",
"ALGO-USD",
"ASTER-USD",
"ATOM-USD",
"AVAX-USD",
"BCH-USD",
"BGB-USD",
"BNB-USD",
"BTC-USD",
"CC-USD",
"CRO-USD",
"DAI-USD",
"DOGE-USD",
"DOT-USD",
"ENA-USD",
"ETC-USD",
"ETH-USD",
"GT-USD",
"HBAR-USD",
"HYPE-USD",
"ICP-USD",
"KAS-USD",
"KCS-USD",
"LEO-USD",
"LINK-USD",
"LTC-USD",
"MNT-USD",
"M-USD",
"NEAR-USD",
"NIGHT-USD",
"OKB-USD",
"ONDO-USD",
"PAXG-USD",
"PEPE-USD",
"PI-USD",
"POL-USD",
"PYUSD-USD",
"QNT-USD",
"RENDER-USD",
"RLUSD-USD",
"SHIB-USD",
"SKY-USD",
"SOL-USD",
"SUI-USD",
"TON-USD",
"TRUMP-USD",
"TRX-USD",
"UNI-USD",
"USD1-USD",
"USDC-USD",
"USDD-USD",
"USDe-USD",
"USDG-USD",
"USDT-USD",
"U-USD",
"WLD-USD",
"WLFI-USD",
"XAUt-USD",
"XLM-USD",
"XMR-USD",
"XRP-USD",
"ZEC-USD",
]
        print("Starting crypto data fetch...")
        
        for symbol in symbols:
            # Fetch recent data to ensure we catch up if missed
            ticker = yf.Ticker(symbol)
            hist = ticker.history(period="5d")
            
            for index, row in hist.iterrows():
                record_date = index.date()
                
                # Prevent duplicates by checking if the exact date + symbol already exists
                existing = db.query(CryptoPrice).filter(
                    CryptoPrice.symbol == symbol,
                    CryptoPrice.date == record_date
                ).first()
                
                if not existing:
                    new_price = CryptoPrice(
                        symbol=symbol,
                        asset_type="Crypto",
                        date=record_date,
                        open=float(row["Open"]),
                        high=float(row["High"]),
                        low=float(row["Low"]),
                        close=float(row["Close"]),
                        volume=float(row["Volume"])
                    )
                    db.add(new_price)
                    print(f"Inserted new data for {symbol} on {record_date}")
                    
            db.commit()
        print("Successfully synchronized data with the database.")
            
    except Exception as e:
        print(f"Error fetching background data: {e}")
        db.rollback()
        raise e
    finally:
        db.close()

if __name__ == "__main__":
    fetch_daily_data()
