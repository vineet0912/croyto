import yfinance as yf
from sqlalchemy.orm import Session
from datetime import datetime

from app.database.database import SessionLocal
from app.model.db_model import CryptoPrice


# ✅ ONLY COMMODITY MAPPING
COMMODITY_MAPPING = {
    "GC=F": "GOLD",
    "SI=F": "SILVER",
    "CL=F": "CRUDE_OIL",
    "NG=F": "NATURAL_GAS",
    "ES=F":"E-Mini S&P 500",
    "YM=F": "Mini Dow Jones",
    "NQ=F":"Nasdaq 100",
    "RTY=F":"Russell 2000",
    "ZB=F":"u.S. Bond", ## done till here 
    "ZN=F":"TEN YEAR TREASURY NOTE",
    "ZT=F":"TWO YEAR TREASURY NOTE",
    "MGC=F":"Micro Gold",
    "SIL=F":"Micro Silver",
    "PL=F":"Platinum",
    "HG=F":"Copper",
    "PA=F":"Palladium",
    "CL=F":"Crude Oil",
    "HO=F":"Heating Oil",
    "NG=F":"Natural Gas",
    "RB=F":"Gasoline",
    "B0=F":"Propane",
    "ZC=F":"Corn",
    "ZO=F":"Oat",
    "KE=F":"Wheat",
    "ZR=F":"Rough Rice",
    "ZL=F":"Soybean Oil",
    "ZS=F":"Soybean",
    "GF=F":"Feeder Cattle",
    "HE=F":"Lean Hogs",
    "LE=F":"Live Cattle",
    "CC=F":"Cocoa",
    "KC=F":"Coffee",
    "CT=F":"Cotton",
    "LBS=F":"Lumber",
    "OJ=F":"Orange Juice",
    "SB=F":"Sugar",
}


def fetch_commodity_data():
    db: Session = SessionLocal()

    try:
        print("📊 Fetching commodity data...")

        for external_symbol, internal_symbol in COMMODITY_MAPPING.items():

            try:
                ticker = yf.Ticker(external_symbol)
                hist = ticker.history(period="5d")

                if hist.empty:
                    print(f"⚠️ No data for {external_symbol}")
                    continue

                for index, row in hist.iterrows():
                    record_date = index.date()

                    # ✅ DUPLICATE CHECK (IMPORTANT)
                    existing = db.query(CryptoPrice).filter(
                        CryptoPrice.symbol == internal_symbol,
                        CryptoPrice.date == record_date
                    ).first()

                    if existing:
                        continue

                    volume = row["Volume"]
                    if volume != volume:
                        volume = None

                    new_price = CryptoPrice(
                        symbol=internal_symbol,  # ✅ MAPPED NAME
                        asset_type="Commodity",
                        date=record_date,
                        open=float(row["Open"]),
                        high=float(row["High"]),
                        low=float(row["Low"]),
                        close=float(row["Close"]),
                        volume=float(volume) if volume is not None else None
                    )

                    db.add(new_price)

                db.commit()
                print(f" Updated {internal_symbol}")

            except Exception as e:
                db.rollback()
                print(f" Error with {external_symbol}: {e}")

        print("Commodity sync completed!")

    except Exception as e:
        db.rollback()
        print(f"🔥 Fatal error: {e}")
        raise e

    finally:
        db.close()


if __name__ == "__main__":
    fetch_commodity_data()