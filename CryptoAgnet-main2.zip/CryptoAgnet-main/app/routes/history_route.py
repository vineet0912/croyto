from typing import Optional
from fastapi import Query
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.database import get_db
from app.services.API_service import get_history
 
history_router= APIRouter()

@history_router.get("/history/{symbol}")
def history(
    symbol: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
    limit: int = Query(100, le=1000),
    offset: int = 0,
    db: Session = Depends(get_db)
):
    data = get_history(db, symbol, start, end, limit, offset)

    if not data:
        raise HTTPException(status_code=404, detail="No data found")

    return  data