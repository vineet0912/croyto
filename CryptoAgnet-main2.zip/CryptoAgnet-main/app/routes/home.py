from fastapi import FastAPI, APIRouter

home_router = APIRouter()

@home_router.get("/")
def home():
    return {"message": "Welcome to the Crypto Agent API"}

@home_router.get("/health")
def health():
    return {"status": "ok"}