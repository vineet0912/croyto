from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.database import get_db
from app.services.API_service import get_latest_price
 
from typing import Optional
from fastapi import Query

price_router = APIRouter()

@price_router.get("/latest/{symbol}")
def latest(symbol: str, db: Session = Depends(get_db)):
    data = get_latest_price(db, symbol)
    
    if not data:
        raise HTTPException(status_code=404, detail="Symbol not found")
    
    return data




