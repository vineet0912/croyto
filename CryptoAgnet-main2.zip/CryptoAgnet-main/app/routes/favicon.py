from fastapi import APIRouter, responses

icon_router = APIRouter()
file_path ='favicon.ico'
@icon_router.get("/favicon.ico")
def favicon():
    return responses.FileResponse(file_path)