from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.services.API_service import get_crypto_data
from app.services.news_service import get_crypto_news
from app.model.investment_agent import investment_agent
from app.services.new_sentiment import analyze_sentiment
# from app.services.sentiments_service import analyze_sentiment
from app.services.technical_service import get_technical_indicators
from app.services.confidance_score import calculate_confidence
from app.database.database import get_db


router = APIRouter()


@router.get("/analyze/{coin}")
def analyze_coin(coin, db: Session = Depends(get_db)):

    crypto_data = get_crypto_data(db, coin)

    news = get_crypto_news(coin.upper())

    sentiment = analyze_sentiment(news)

    technical = get_technical_indicators(db, coin)

    rsi_value = technical.get('rsi') if technical.get('rsi') is not None else 50
    # rsi_signal = technical.get('rsi_signal') if technical.get('rsi_signal') is not None else "NEUTRAL"
    confidence = calculate_confidence(
        sentiment["sentiment_score"],
        rsi_value
    )
        

    prompt = f"""
You are an expert crypto investment analyst.

Analyze the following data and provide a clear, structured investment decision.

========================
📊 MARKET DATA
========================
Crypto Data:
{crypto_data}

Technical Indicators:
{technical}

Sentiment Score:
{sentiment}

Confidence Score:
{confidence}

Recent News:
{news}

========================
📈 ANALYSIS INSTRUCTIONS
========================

1. Evaluate the TREND using technical indicators (RSI, MA, price).
2. Interpret sentiment and confidence:
   - High sentiment + high confidence → bullish
   - Low sentiment + low confidence → bearish
3. Consider news impact (positive / negative / neutral).
4. Combine ALL signals — do NOT rely on just one.

========================
📊 OUTPUT FORMAT (STRICT)
========================

Return your response in this exact structure:

Decision: BUY / HOLD / SELL

Confidence Level: (Low / Medium / High)

Reasoning:
- Technical Analysis: (RSI, MA trend, price behavior)
- Sentiment Analysis: (bullish/bearish with explanation)
- News Impact: (how news affects price)
- Final Justification: (why this decision)

Risk Level: (Low / Medium / High)

Short Summary (1-2 lines for UI)

========================
IMPORTANT RULES:
========================
- Be precise and not generic
- Do not hallucinate data
- If signals conflict → prefer HOLD
- Avoid financial advice disclaimers
"""




    response = investment_agent.run(prompt)

    return {
        "crypto_data": crypto_data,
        "technical_indicator": technical,
        "confidence": confidence,
        "sentiment": sentiment,
        "confidance_score": confidence,
        "news": news,
        "analysis": response

    }
