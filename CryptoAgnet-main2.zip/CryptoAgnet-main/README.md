<div align="center">

# 🪙 Crypto Investment Analyzer

### _AI-Powered Cryptocurrency Analysis & Investment Insights Engine_

[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.100+-009688?style=for-the-badge&logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com)
[![Groq](https://img.shields.io/badge/Groq-LLaMA_3.3_70B-F55036?style=for-the-badge&logo=meta&logoColor=white)](https://groq.com)
[![HuggingFace](https://img.shields.io/badge/HuggingFace-Transformers-FFD21E?style=for-the-badge&logo=huggingface&logoColor=black)](https://huggingface.co)

---

_A real-time crypto intelligence platform that combines **live market data**, **news sentiment analysis**, **technical indicators**, and **AI-powered agents** to deliver comprehensive investment insights for any cryptocurrency._

</div>

---

## 📐 Architecture Diagram

<div align="center">

![Architecture Diagram](docs/architecture_diagram.png)

</div>

### Data Flow

```
Client Requests (/analyze, /latest, /history)
        │
        ▼
   ┌─────────┐
   │ FastAPI  │
   │ Server   │
   └────┬─────┘
        │
        ▼
┌───────────────────────┐
│   API Route Layer     │
│ (Analysis/Price/Hist) │
└───────┬───────────────┘
        │
        ├──────────────┬──────────────┬──────────────┐
        ▼              ▼              ▼              ▼
 ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌────────────┐
 │  Crypto    │ │   News     │ │ Sentiment  │ │ Technical  │
 │  Service   │ │  Service   │ │  Service   │ │  Service   │
 │            │ │            │ │            │ │            │
 │ postgres   │ │  NewsAPI   │ │ HuggingFace│ │ Pandas +TA │
 └─────┬──────┘ └─────┬──────┘ └─────┬──────┘ └─────┬──────┘
       │               │              │              │
       └───────┬───────┴──────┬───────┘              │
               │              │                      │
               ▼              ▼                      │
        ┌─────────────────────────────┐              │
        │   Confidence Score Engine   │◄─────────────┘
        │  (Sentiment + RSI Fusion)   │
        └──────────┬──────────────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │   AI Agent Layer     │
        │  ┌────────────────┐  │
        │  │ Investment     │  │
        │  │ Agent          │  │
        │  └────────────────┘  │
        │  Groq LLaMA 3.3 70B │
        │  via Agno Framework  │
        └──────────┬───────────┘
                   │
                   ▼
          ┌────────────────┐
          │  JSON Response │
          │  (Full Report) │
          └────────────────┘
```

---

## 🗂️ Project Structure

```
CRYPTO_model/
│
├── 📄 .env                        # API keys (CoinGecko, NewsAPI, Groq)
├── 📄 .gitignore                  # Git ignore rules
├── 📄 requirements.txt            # Python dependencies
├── 📄 README.md                   # Project documentation
│
├── 📁 docs/
│   └── 🖼️ architecture_diagram.png # System architecture visual
│
└── 📁 app/                        # Main application package
    │
    ├── 📄 main.py                 # FastAPI app entry point
    │
    ├── 📁 database/               # Database setup & session management
    │   └── 📄 database.py         # SQLAlchemy engine and sessionmaker
    │
    ├── 📁 model/                  # AI Agent definitions
    │   ├── 📄 investment_agent.py # Primary investment advisor agent
    │   ├── 📄 market_agent.py     # Market trend analysis agent
    │   └── 📄 news_agent.py       # News sentiment analysis agent
    │
    ├── 📁 routes/                 # API route handlers
    │   ├── 📄 __init__.py
    │   ├── 📄 analysis_route.py   # /analyze/{coin} endpoint logic
    │   ├── 📄 history_route.py    # /history/{symbol} endpoint logic
    │   └── 📄 latest_price_route.py # /latest/{symbol} endpoint logic
    │
    └── 📁 services/               # Business logic & external integrations
        ├── 📄 __init__.py
        ├── 📄 crypto_service.py   # CoinGecko market data fetcher
        ├── 📄 news_service.py     # NewsAPI headline aggregator
        ├── 📄 sentiments_service.py # HuggingFace sentiment pipeline
        ├── 📄 technical_service.py # RSI & MA50 technical indicators
        └── 📄 confidance_score.py # Confidence score calculator
```

---

## 🛠️ Technology Stack

| Layer | Technology | Purpose |
|:------|:-----------|:--------|
| **Web Framework** | ![FastAPI](https://img.shields.io/badge/-FastAPI-009688?style=flat-square&logo=fastapi&logoColor=white) FastAPI | High-performance async REST API server |
| **ASGI Server** | ![Uvicorn](https://img.shields.io/badge/-Uvicorn-2C2C2C?style=flat-square&logo=uvicorn&logoColor=white) Uvicorn | Lightning-fast ASGI server for production |
| **AI Framework** | ![Agno](https://img.shields.io/badge/-Agno-7C3AED?style=flat-square) Agno | Agent orchestration framework for LLM-powered agents |
| **LLM Provider** | ![Groq](https://img.shields.io/badge/-Groq-F55036?style=flat-square) Groq | Ultra-fast inference with **LLaMA 3.3 70B Versatile** |
| **NLP / Sentiment** | ![HuggingFace](https://img.shields.io/badge/-Transformers-FFD21E?style=flat-square&logo=huggingface&logoColor=black) Transformers | Pre-trained sentiment analysis pipeline |
| **Market Data** | ![CoinGecko](https://img.shields.io/badge/-CoinGecko-8DC63F?style=flat-square) CoinGecko API | Real-time crypto prices, market cap, and volume |
| **News Data** | ![NewsAPI](https://img.shields.io/badge/-NewsAPI-1D1D1D?style=flat-square) NewsAPI | Latest cryptocurrency news headlines |
| **Database** | ![SQLAlchemy](https://img.shields.io/badge/-SQLAlchemy-D71F00?style=flat-square) SQLAlchemy | ORM for storing and querying market history |
| **Data Analysis** | ![Pandas](https://img.shields.io/badge/-Pandas-150458?style=flat-square&logo=pandas&logoColor=white) Pandas | Data manipulation and time-series processing |
| **Technical Analysis** | ![TA](https://img.shields.io/badge/-TA_Lib-FF6B35?style=flat-square) TA (Technical Analysis) | RSI, Moving Averages, and other indicators |
| **HTTP Client** | ![Requests](https://img.shields.io/badge/-Requests-2B5B84?style=flat-square) Requests | External API communication |
| **Config Management** | ![dotenv](https://img.shields.io/badge/-python--dotenv-ECD53F?style=flat-square) python-dotenv | Secure environment variable loading |

---

## 🤖 AI Agents

The system leverages three specialized AI agents built with the **Agno** framework, all powered by **Groq's LLaMA 3.3 70B Versatile** model:

| Agent | Role | Analyzes |
|:------|:-----|:---------|
| 🧠 **Investment Agent** | Primary advisor — produces market outlook, risks, and investment insights | All aggregated data (market, news, sentiment, technical, confidence) |
| 📊 **Market Agent** | Determines bullish/bearish trends, volume strength, and volatility | Raw crypto market data |
| 📰 **News Agent** | Identifies sentiment, market impact, and positive/negative signals | Crypto news headlines |

---

## 🔌 API Reference

### 1️⃣ `GET /analyze/{coin}`

Performs a full AI-driven analysis pipeline for the specified cryptocurrency, combining market data, technical indicators, and news sentiment.

**Path Parameter:**

| Parameter | Type | Example | Description |
|:----------|:-----|:--------|:------------|
| `coin` | `string` | `BTC-USD` | Yfinance coin ID (e.g., `bitcoin`, `ethereum`) |

**Response Schema:**

```json
{
  "crypto_data": {
    "price": 67432.12,
    "market_cap": 1325000000000,
    "volume": 28500000000,
    "change_24h": 2.45
  },
  "technical_indicator": {
    "rsi": 58.34,
    "ma50": 65120.50,
    "price": 67432.12
  },
  "confidence": 72.15,
  "sentiment": {
    "sentiment_score": 0.45,
    "sentiment_label": "bullish"
  },
  "news": [
    {
      "title": "Bitcoin Surges Past $67K...",
      "url": "https://...",
      "source": "CoinDesk"
    }
  ],
  "analysis": "AI-generated investment insight..."
}
```

### 2️⃣ `GET /latest/{symbol}`

Retrieves the most recent price and market data for a given cryptocurrency from the database.

**Path Parameter:**

| Parameter | Type | Example | Description |
|:----------|:-----|:--------|:------------|
| `symbol` | `string` | `BTC-USD` |  Yfinance coin ID (e.g., `bitcoin`, `solana`) |

**Response Schema:**

```json
{
{
  "crypto_data": {
    "symbol": "BTC-USD",
    "date": "2026-03-29",
    "price": 67000.25,
    "open": 66331.703125,
    "high": 67000.25,
    "low": 66287.0234375,
    "volume": 20603142144
  },
  "technical_indicator": {
    "rsi": 43.29,
    "ma50": 69133.21,
    "price": 67000.25
  },
  "confidence": 69.6,
  "sentiment": {
    "sentiment_score": -0.99,
    "sentiment_label": "bearish"
  },
  "confidance_score": 69.6,
  "news": [
    {
      "title": "xfinance added to PyPI",
      "url": "https://pypi.org/project/xfinance/",
      "source": "Pypi.org"
    },
    {
      ....
    },
    "analysis": {
    "run_id": "a5414743-4bee-46a6-a914-0763cc64aaab",
    "agent_id": "crypto-investment-advisor",
    "agent_name": "Crypto Investment Advisor",
    "session_id": "d8567666-66b1-484e-a509-963f4d63eea6",
    "parent_run_id": null,
    "workflow_id": null,
    "user_id": null,
    "input": {
      "input_content": "\n    Crypto Data:\n    {'symbol': 'BTC-USD', 'date': '2026-03-29', 'price': 67000.25, 'open': 66331.703125, 'high': 67000.25, 'low': 66287.0234375, 'volume': 20603142144.0}\n\n    News:\n    [{'title': 'xfinance added to PyPI', 'url': 'https://pypi.org/project/xfinance/', 'source': 'Pypi.org'}, {'title': \"Bitcoin dips under $66K as oil sparks 'unsustainable' US inflation risk\", 'url': 'https://cointelegraph.com/markets/bitcoin-dips-under-66k-oil-sparks-unsustainable-inflation-risk', 'source': 'Cointelegraph'}, {'title': 'Technate, Ohio: How Leslie Wexner and Jeffrey Epstein Built The Silicon Heartland', 'url': 'https://www.activistpost.com/technate-ohio-how-leslie-wexner-and-jeffrey-epstein-built-the-silicon-heartland/', 'source': 'Activistpost.com'}, {'title': 'Bitcoin nears lowest in three weeks as BTC price targets drop to $41K', 'url': 'https://cointelegraph.com/markets/bitcoin-nears-lowest-in-three-weeks-btc-price-targets-drop-41k', 'source': 'Cointelegraph'}, {'title': 'Bitcoin holders show ‘stronger’ conviction despite BTC price losing $68K level', 'url': 'https://cointelegraph.com/markets/bitcoin-holders-show-stronger-conviction-despite-btc-price-losing-68k', 'source': 'Cointelegraph'}]\n\n    Sentiment:\n    {'sentiment_score': -0.99, 'sentiment_label': 'bearish'}\n\n    Technical:\n    {'rsi': np.float64(43.29), 'ma50': np.float64(69133.21), 'price': np.float64(67000.25)}\n\n    confidence:\n    69.6\n\n    Analyze and give investment insight.\n    ",
      "images": null,
      "videos": null,
      "audios": null,
      "files": null
    },
    "content": "AI response"
    },

    {
      "id": "b4c0fbae-6c35-44ea-a810-1d369bd48d74",
        "role": "assistant",
        "content": "**Market Outlook:**\nThe current market outlook for Bitcoin (BTC-USD) appears bearish, with a sentiment score of -0.99 and a label of 'bearish'. The price has dipped under $66K, and news articles suggest that oil prices are sparking concerns about \"unsustainable\" US inflation risk. Additionally, technical indicators such as the Relative Strength Index (RSI) at 43.29 and the 50-day Moving Average (MA50) at $69,133.21 are indicating a potential downtrend.\n\n**Risks:**\nThe main risks associated with investing in Bitcoin at this time include:\n\n1. **Inflation Risk**: The current inflation concerns sparked by oil prices may lead to a decrease in investor confidence, causing a further decline in Bitcoin's price.\n2. **Market Volatility**: The cryptocurrency market is known for its volatility, and the current bearish sentiment may lead to increased price fluctuations.\n3. **Technical Resistance**: The MA50 at $69,133.21 may act as a resistance level, making it difficult for the price to break above this level.\n\n**Short Investment Insight:**\nBased on the current market data and news sentiment, I would advise a **short-term bearish** stance on Bitcoin. The sentiment score and label suggest a strong bearish outlook, and the technical indicators are indicating a potential downtrend. However, it's essential to note that the confidence level is at 69.6, which is relatively moderate.\n\n**Investment Strategy:**\nFor a short-term investment, I would recommend a **sell** or **short** position on Bitcoin, with a target price of $41K, as suggested by one of the news articles. However, it's crucial to set a stop-loss at around $68K to limit potential losses if the price were to break above the MA50 level. Additionally, investors should be prepared for increased market volatility and potential price fluctuations.\n\n**Disclaimer:**\nThis investment insight is based on current market data and news sentiment and should not be considered as personalized investment advice. Investors should always conduct their own research and consult with a financial advisor before making any investment decisions.",
    },
}
```

### 3️⃣ `GET /history/{symbol}`

Fetches historical market data for a specific cryptocurrency, supporting pagination and date filtering.

**Path Parameter:**

| Parameter | Type | Example | Description |
|:----------|:-----|:--------|:------------|
| `symbol` | `string` | `BTC-USD` | YFinance coin ID |

**Query Parameters:**

| Parameter | Type | Default | Description |
|:----------|:-----|:--------|:------------|
| `start` | `string` | `null` | Optional start date/time (e.g., `2023-01-01`) |
| `end` | `string` | `null` | Optional end date/time (e.g., `2023-10-25`) |
| `limit` | `integer` | `100` | Max number of records to return (max `1000`) |
| `offset` | `integer` | `0` | Number of records to skip for pagination |

**Response Schema:**

```json
[
{
    "volume": 20597699541,
    "id": 8485,
    "date": "2024-06-10",
    "open": 69644.3125,
    "high": 70146.0703125,
    "low": 69232.421875,
    "close": 69512.28125,
    "symbol": "BTC-USD"
  },
  {
    "volume": 13534028500,
    "id": 8484,
    "date": "2024-06-09",
    "open": 69297.4921875,
    "high": 69817.5234375,
    "low": 69160.84375,
    "close": 69647.9921875,
    "symbol": "BTC-USD"
  },
  {
    "volume": 14262185861,
    "id": 8483,
    "date": "2024-06-08",
    "open": 69324.1796875,
    "high": 69533.3203125,
    "low": 69210.7421875,
    "close": 69305.7734375,
    "symbol": "BTC-USD"
  },
  {
"etc.,"
  },

]
 
```

### 4 GET /latest/{symbol}
Fetches historical market data for a specific cryptocurrency, supporting pagination and date filtering.

**Path Parameter:**

| Parameter | Type | Example | Description |
|:----------|:-----|:--------|:------------|
| `symbol` | `string` | `BTC-USD` | YFinance coin ID |


**Response Schema**
```json
{
  "volume": 20603142144,
  "id": 185683,
  "date": "2026-03-29",
  "open": 66331.703125,
  "high": 67000.25,
  "low": 66287.0234375,
  "close": 67000.25,
  "symbol": "BTC-USD"
}



```

---

## 🧩 Core Modules Deep Dive

### 📡 Crypto Service (`crypto_service.py`)
Fetches real-time market data from the **CoinGecko API v3** including current price (USD), market capitalization, 24h trading volume, and 24h price change percentage.

### 📰 News Service (`news_service.py`)
Aggregates the 5 most recent English-language news articles for a given coin from **NewsAPI**, extracting titles, URLs, and source names.

### 💬 Sentiment Service (`sentiments_service.py`)
Runs each news headline through a **HuggingFace Transformers** sentiment analysis pipeline. Positive scores are kept as-is, negative scores are inverted. The average produces a composite sentiment score classified as **bullish** (> 0.2), **bearish** (< -0.2), or **neutral**.

### 📈 Technical Service (`technical_service.py`)
Pulls 30 days of historical price data from CoinGecko, then computes:
- **RSI** (Relative Strength Index) — momentum oscillator
- **MA50** (50-period Moving Average) — trend indicator

### 🎯 Confidence Score Engine (`confidance_score.py`)
Fuses sentiment and technical signals into a single confidence percentage:
- **40% weight** → Sentiment strength (absolute score)
- **60% weight** → Technical signal (RSI-based: >60 → 0.8, <40 → 0.6, else → 0.5)

---

## 🔐 Environment Variables

| Variable | Service | Description |
|:---------|:--------|:------------|
| `NEWS_API` | NewsAPI | API key for fetching news headlines |
| `GROQ_API` | Groq | API key for LLaMA 3.3 70B inference |
| `CRYPTOPANIC_API` | CryptoPanic | _(Reserved)_ Alternative news source key |
| `DATABASE_URL` | postgres | postgres db connection string |

---

### Crypto List
```
{
"AAVE-USD",
"ADA-USD",
"ALGO-USD",
"ASTER-USD",
"ATOM-USD",
"AVAX-USD",
"BCH-USD",
"BGB-USD",
"BNB-USD",
"BTC-USD",
"CC-USD",
"CRO-USD",
"DAI-USD",
"DOGE-USD",
"DOT-USD",
"ENA-USD",
"ETC-USD",
"ETH-USD",
"GT-USD",
"HBAR-USD",
"HYPE-USD",
"ICP-USD",
"KAS-USD",
"KCS-USD",
"LEO-USD",
"LINK-USD",
"LTC-USD",
"MNT-USD",
"M-USD",
"NEAR-USD",
"NIGHT-USD",
"OKB-USD",
"ONDO-USD",
"PAXG-USD",
"PEPE-USD",
"PI-USD",
"POL-USD",
"PYUSD-USD",
"QNT-USD",
"RENDER-USD",
"RLUSD-USD",
"SHIB-USD",
"SKY-USD",
"SOL-USD",
"SUI-USD",
"TON-USD",
"TRUMP-USD",
"TRX-USD",
"UNI-USD",
"USD1-USD",
"USDC-USD",
"USDD-USD",
"USDe-USD",
"USDG-USD",
"USDT-USD",
"U-USD",
"WLD-USD",
"WLFI-USD",
"XAUt-USD",
"XLM-USD",
"XMR-USD",
"XRP-USD",
"ZEC-USD",
}
```
### Commodities list 
```
{
  yfinance: Database labels
   "GC=F": "GOLD",
    "SI=F": "SILVER",
    "CL=F": "CRUDE_OIL",
    "NG=F": "NATURAL_GAS",
    "ES=F":"E-Mini S&P 500",
    "YM=F": "Mini Dow Jones",
    "NQ=F":"Nasdaq 100",
    "RTY=F":"Russell 2000",
    "ZB=F":"u.S. Bond", ## done till here 
    "ZN=F":"TEN YEAR TREASURY NOTE",
    "ZT=F":"TWO YEAR TREASURY NOTE",
    "MGC=F":"Micro Gold",
    "SIL=F":"Micro Silver",
    "PL=F":"Platinum",
    "HG=F":"Copper",
    "PA=F":"Palladium",
    "CL=F":"Crude Oil",
    "HO=F":"Heating Oil",
    "NG=F":"Natural Gas",
    "RB=F":"Gasoline",
    "B0=F":"Propane",
    "ZC=F":"Corn",
    "ZO=F":"Oat",
    "KE=F":"Wheat",
    "ZR=F":"Rough Rice",
    "ZL=F":"Soybean Oil",
    "ZS=F":"Soybean",
    "GF=F":"Feeder Cattle",
    "HE=F":"Lean Hogs",
    "LE=F":"Live Cattle",
    "CC=F":"Cocoa",
    "KC=F":"Coffee",
    "CT=F":"Cotton",
    "LBS=F":"Lumber",
    "OJ=F":"Orange Juice",
    "SB=F":"Sugar", 
}
```
## 📜 License

This project is open source and available under the [MIT License](LICENSE).

---

<div align="center">

_Built with ⚡ FastAPI · 🧠 Groq LLaMA · 🤗 HuggingFace · 📊 CoinGecko_

</div>
